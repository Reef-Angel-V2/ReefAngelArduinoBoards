This contains the information for the Reef Angel Controllers.

The following folders were just copied from the default Arduino 1.8.10 folders:
	* cores
	* libraries

The platform.txt file was also copied from Arduino 1.8.10 with the name changed to Reef Angel Controllers.

Releases:
1.0.0 - Initial Release - 1/26/2020
	* All current boards are included

Support Website:  https://forum.reefangel.com